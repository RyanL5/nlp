Attention: 
* Before execute main.py, please create virtual environment and install all requirements from requirements.txt. 
* Certain system may fail to download certain nltk packets which is used in main.py because SSL:'CERTIFICATES_VERIFY_FAILED'. To solve this problem, go to the folder where Python installed and click on 'install Certificates.command'. 
* The evaluation features are included in main.py